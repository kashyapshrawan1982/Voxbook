package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.audio.TtsAudioEngine
import com.example.data.db.AppDatabase
import com.example.data.model.BookItem
import com.example.data.parser.FileParser
import com.example.data.translation.TranslationLanguage
import com.example.data.translation.TranslationService
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BookViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val bookDao = db.bookDao()

    val ttsAudioEngine = TtsAudioEngine(application)

    val allBooks: StateFlow<List<BookItem>> = bookDao.getAllBooks()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _currentBook = MutableStateFlow<BookItem?>(null)
    val currentBook: StateFlow<BookItem?> = _currentBook.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(TranslationLanguage.SUPPORTED_LANGUAGES[0]) // Hindi default
    val selectedLanguage: StateFlow<TranslationLanguage> = _selectedLanguage.asStateFlow()

    private val _isParsing = MutableStateFlow(false)
    val isParsing: StateFlow<Boolean> = _isParsing.asStateFlow()

    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    private val _translationProgress = MutableStateFlow(0f)
    val translationProgress: StateFlow<Float> = _translationProgress.asStateFlow()

    private val _uiEvent = MutableSharedFlow<String>()
    val uiEvent: SharedFlow<String> = _uiEvent.asSharedFlow()

    fun selectLanguage(language: TranslationLanguage) {
        _selectedLanguage.value = language
    }

    fun parseAndLoadFile(uri: Uri, onComplete: (Long) -> Unit) {
        viewModelScope.launch {
            _isParsing.value = true
            try {
                val parsed = FileParser.parseFile(getApplication(), uri)
                val words = parsed.text.split(Regex("""\s+""")).filter { it.isNotBlank() }.size
                val chars = parsed.text.length

                val newBook = BookItem(
                    title = parsed.fileName,
                    fileType = parsed.fileType,
                    originalText = parsed.text,
                    translatedText = "",
                    sourceLanguage = "Auto",
                    targetLanguage = "Original",
                    targetLanguageCode = "en",
                    wordCount = words,
                    charCount = chars
                )

                val id = bookDao.insertBook(newBook)
                val savedBook = newBook.copy(id = id)
                _currentBook.value = savedBook
                _uiEvent.emit("Successfully parsed ${parsed.fileName}")
                onComplete(id)
            } catch (e: Exception) {
                e.printStackTrace()
                _uiEvent.emit("Failed to parse file: ${e.localizedMessage}")
            } finally {
                _isParsing.value = false
            }
        }
    }

    fun translateBook(book: BookItem, targetLang: TranslationLanguage, onComplete: () -> Unit) {
        viewModelScope.launch {
            _isTranslating.value = true
            _translationProgress.value = 0.05f
            try {
                val textToTranslate = book.originalText
                val translated = TranslationService.translateText(
                    text = textToTranslate,
                    sourceLangCode = "auto",
                    targetLang = targetLang,
                    onProgress = { progress ->
                        _translationProgress.value = progress
                    }
                )

                val updatedBook = book.copy(
                    translatedText = translated,
                    targetLanguage = targetLang.name,
                    targetLanguageCode = targetLang.code
                )

                bookDao.updateBook(updatedBook)
                _currentBook.value = updatedBook
                _uiEvent.emit("Translation to ${targetLang.name} complete!")
                onComplete()
            } catch (e: Exception) {
                e.printStackTrace()
                _uiEvent.emit("Translation error: ${e.localizedMessage}")
            } finally {
                _isTranslating.value = false
            }
        }
    }

    fun prepareAudioPlayback(book: BookItem, language: TranslationLanguage) {
        val textToSpeak = if (book.translatedText.isNotBlank()) {
            book.translatedText
        } else {
            book.originalText
        }
        ttsAudioEngine.prepareText(textToSpeak, language)
    }

    fun exportAudio(
        book: BookItem,
        language: TranslationLanguage,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val textToExport = if (book.translatedText.isNotBlank()) {
                book.translatedText
            } else {
                book.originalText
            }

            try {
                val filePath = ttsAudioEngine.exportAudioToMediaStore(
                    bookTitle = book.title,
                    fullText = textToExport,
                    language = language,
                    onProgress = {}
                )
                
                // Update book with audio file path
                val updatedBook = book.copy(audioFilePath = filePath)
                bookDao.updateBook(updatedBook)
                _currentBook.value = updatedBook
                _uiEvent.emit("Audio saved to $filePath")
                onSuccess(filePath)
            } catch (e: Exception) {
                e.printStackTrace()
                onError(e.localizedMessage ?: "Export failed")
            }
        }
    }

    fun setCurrentBook(book: BookItem) {
        _currentBook.value = book
    }

    fun loadBookById(id: Long) {
        viewModelScope.launch {
            val book = bookDao.getBookById(id)
            if (book != null) {
                _currentBook.value = book
            }
        }
    }

    fun deleteBook(book: BookItem) {
        viewModelScope.launch {
            bookDao.deleteBook(book)
            if (_currentBook.value?.id == book.id) {
                _currentBook.value = null
            }
            _uiEvent.emit("Deleted ${book.title}")
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsAudioEngine.shutdown()
    }
}
