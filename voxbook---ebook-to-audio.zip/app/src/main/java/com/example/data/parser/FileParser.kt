package com.example.data.parser

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.util.zip.ZipInputStream
import java.util.zip.InflaterInputStream

object FileParser {

    data class ParsedResult(
        val fileName: String,
        val fileType: String,
        val text: String,
        val fileSizeFormatted: String
    )

    fun parseFile(context: Context, uri: Uri): ParsedResult {
        val fileName = getFileName(context, uri) ?: "Document"
        val fileSize = getFileSize(context, uri)
        val fileType = when {
            fileName.endsWith(".pdf", ignoreCase = true) -> "PDF"
            fileName.endsWith(".epub", ignoreCase = true) -> "EPUB"
            else -> "TXT"
        }

        val text = context.contentResolver.openInputStream(uri)?.use { inputStream ->
            when (fileType) {
                "TXT" -> parseTxt(inputStream)
                "PDF" -> parsePdf(inputStream)
                "EPUB" -> parseEpub(inputStream)
                else -> parseTxt(inputStream)
            }
        } ?: throw IllegalStateException("Could not open input stream for file")

        val cleanedText = cleanExtractedText(text)
        return ParsedResult(
            fileName = fileName,
            fileType = fileType,
            text = cleanedText,
            fileSizeFormatted = formatFileSize(fileSize)
        )
    }

    private fun parseTxt(inputStream: InputStream): String {
        return BufferedReader(InputStreamReader(inputStream, StandardCharsets.UTF_8)).use { reader ->
            reader.readText()
        }
    }

    private fun parseEpub(inputStream: InputStream): String {
        val stringBuilder = StringBuilder()
        ZipInputStream(inputStream).use { zipStream ->
            var entry = zipStream.nextEntry
            while (entry != null) {
                val name = entry.name.lowercase()
                if ((name.endsWith(".xhtml") || name.endsWith(".html") || name.endsWith(".htm"))
                    && !name.contains("toc") && !name.contains("cover")
                ) {
                    val content = BufferedReader(InputStreamReader(zipStream, StandardCharsets.UTF_8)).use {
                        val sb = StringBuilder()
                        var line: String? = zipStream.bufferedReader().readLine()
                        while (line != null) {
                            sb.append(line).append("\n")
                            line = zipStream.bufferedReader().readLine()
                        }
                        sb.toString()
                    }
                    stringBuilder.append(stripHtmlTags(content)).append("\n\n")
                }
                zipStream.closeEntry()
                entry = zipStream.nextEntry
            }
        }
        val result = stringBuilder.toString()
        return if (result.isBlank()) "No readable text content found in EPUB document." else result
    }

    private fun parsePdf(inputStream: InputStream): String {
        val bytes = inputStream.readBytes()
        val textBuilder = StringBuilder()

        val rawContent = String(bytes, StandardCharsets.ISO_8859_1)
        
        // Match BT (Begin Text) to ET (End Text) blocks in PDF
        val btEtRegex = Regex("""BT\s*(.*?)\s*ET""", RegexOption.DOT_MATCHES_ALL)
        val matches = btEtRegex.findAll(rawContent).toList()

        if (matches.isNotEmpty()) {
            for (match in matches) {
                val block = match.groupValues[1]
                extractTextFromPdfBlock(block, textBuilder)
            }
        }

        if (textBuilder.isBlank()) {
            // Fallback: extract bracketed text strings (string literals in PDF: (text))
            val literalStringRegex = Regex("""\(([^()]{2,})\)""")
            literalStringRegex.findAll(rawContent).forEach { matchResult ->
                val str = matchResult.groupValues[1]
                if (isLikelyReadableText(str)) {
                    textBuilder.append(str).append(" ")
                }
            }
        }

        val result = textBuilder.toString().trim()
        return if (result.isBlank()) {
            "Extracted document text from PDF. (If this document is a scanned image PDF, text extraction requires an OCR scanner)."
        } else {
            result
        }
    }

    private fun extractTextFromPdfBlock(block: String, textBuilder: StringBuilder) {
        // Look for Tj or TJ operators
        val tjRegex = Regex("""\((.*?)\)\s*Tj""")
        tjRegex.findAll(block).forEach { match ->
            val text = decodePdfString(match.groupValues[1])
            textBuilder.append(text).append(" ")
        }

        val tjArrayRegex = Regex("""\[(.*?)\]\s*TJ""", RegexOption.DOT_MATCHES_ALL)
        tjArrayRegex.findAll(block).forEach { match ->
            val arrayContent = match.groupValues[1]
            val innerRegex = Regex("""\((.*?)\)""")
            innerRegex.findAll(arrayContent).forEach { innerMatch ->
                textBuilder.append(decodePdfString(innerMatch.groupValues[1]))
            }
            textBuilder.append(" ")
        }
    }

    private fun decodePdfString(input: String): String {
        return input
            .replace("\\)", ")")
            .replace("\\(", "(")
            .replace("\\n", "\n")
            .replace("\\r", "\r")
            .replace("\\t", "\t")
            .replace("\\\\", "\\")
    }

    private fun isLikelyReadableText(str: String): Boolean {
        if (str.length < 3) return false
        val alphaCount = str.count { it.isLetter() }
        return (alphaCount.toDouble() / str.length) > 0.4
    }

    private fun stripHtmlTags(html: String): String {
        val noTags = html.replace(Regex("""<[^>]*>"""), " ")
        return noTags
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    private fun cleanExtractedText(raw: String): String {
        return raw.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .joinToString("\n\n")
    }

    fun getFileName(context: Context, uri: Uri): String? {
        var name: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1 && cursor.moveToFirst()) {
                    name = cursor.getString(nameIndex)
                }
            }
        }
        if (name == null) {
            name = uri.path
            val cut = name?.lastIndexOf('/')
            if (cut != null && cut != -1) {
                name = name.substring(cut + 1)
            }
        }
        return name
    }

    private fun getFileSize(context: Context, uri: Uri): Long {
        var size: Long = 0
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (sizeIndex != -1 && cursor.moveToFirst()) {
                    size = cursor.getLong(sizeIndex)
                }
            }
        }
        return size
    }

    private fun formatFileSize(size: Long): String {
        if (size <= 0) return "Unknown size"
        val kb = size / 1024.0
        val mb = kb / 1024.0
        return when {
            mb >= 1.0 -> String.format("%.1f MB", mb)
            else -> String.format("%.0f KB", kb)
        }
    }
}
