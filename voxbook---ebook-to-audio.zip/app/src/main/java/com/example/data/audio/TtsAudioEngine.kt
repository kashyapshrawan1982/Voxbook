package com.example.data.audio

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.data.translation.TranslationLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale

class TtsAudioEngine(private val context: Context) : TextToSpeech.OnInitListener {

    data class PlaybackState(
        val isInitialized: Boolean = false,
        val isPlaying: Boolean = false,
        val isPaused: Boolean = false,
        val currentChunkIndex: Int = 0,
        val totalChunks: Int = 0,
        val speechRate: Float = 1.0f,
        val pitch: Float = 1.0f,
        val currentTextChunk: String = "",
        val isSynthesizing: Boolean = false,
        val synthesisProgress: Float = 0f,
        val statusMessage: String = ""
    )

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private var textChunks = listOf<String>()
    private var currentLanguage = TranslationLanguage.SUPPORTED_LANGUAGES.first()

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            _playbackState.value = _playbackState.value.copy(
                isInitialized = true,
                statusMessage = "TTS Engine Ready"
            )
            setupUtteranceListener()
        } else {
            _playbackState.value = _playbackState.value.copy(
                isInitialized = false,
                statusMessage = "TTS Initialization Failed"
            )
        }
    }

    private fun setupUtteranceListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _playbackState.value = _playbackState.value.copy(isPlaying = true, isPaused = false)
            }

            override fun onDone(utteranceId: String?) {
                val currentIndex = _playbackState.value.currentChunkIndex
                val total = _playbackState.value.totalChunks
                if (currentIndex + 1 < total && _playbackState.value.isPlaying) {
                    val nextIndex = currentIndex + 1
                    _playbackState.value = _playbackState.value.copy(
                        currentChunkIndex = nextIndex,
                        currentTextChunk = textChunks.getOrElse(nextIndex) { "" }
                    )
                    speakChunk(nextIndex)
                } else {
                    _playbackState.value = _playbackState.value.copy(isPlaying = false, isPaused = false)
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                _playbackState.value = _playbackState.value.copy(
                    isPlaying = false,
                    statusMessage = "TTS Playback Error"
                )
            }
        })
    }

    fun prepareText(text: String, language: TranslationLanguage) {
        currentLanguage = language
        textChunks = splitTextIntoTtsChunks(text)
        
        tts?.let { engine ->
            val result = engine.setLanguage(language.locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Try fallback locale or general language code
                engine.language = Locale(language.code)
            }
        }

        _playbackState.value = _playbackState.value.copy(
            currentChunkIndex = 0,
            totalChunks = textChunks.size,
            currentTextChunk = textChunks.firstOrNull() ?: "",
            isPlaying = false,
            isPaused = false
        )
    }

    fun play() {
        val state = _playbackState.value
        if (!state.isInitialized || textChunks.isEmpty()) return
        
        tts?.setSpeechRate(state.speechRate)
        tts?.setPitch(state.pitch)
        
        speakChunk(state.currentChunkIndex)
    }

    private fun speakChunk(index: Int) {
        if (index !in textChunks.indices) return
        val chunk = textChunks[index]
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "VoxBook_Utterance_$index")
        }
        tts?.speak(chunk, TextToSpeech.QUEUE_FLUSH, params, "VoxBook_Utterance_$index")
        _playbackState.value = _playbackState.value.copy(
            isPlaying = true,
            isPaused = false,
            currentChunkIndex = index,
            currentTextChunk = chunk
        )
    }

    fun pause() {
        tts?.stop()
        _playbackState.value = _playbackState.value.copy(isPlaying = false, isPaused = true)
    }

    fun stop() {
        tts?.stop()
        _playbackState.value = _playbackState.value.copy(
            isPlaying = false,
            isPaused = false,
            currentChunkIndex = 0,
            currentTextChunk = textChunks.firstOrNull() ?: ""
        )
    }

    fun setSpeechRate(rate: Float) {
        tts?.setSpeechRate(rate)
        _playbackState.value = _playbackState.value.copy(speechRate = rate)
    }

    fun setPitch(pitch: Float) {
        tts?.setPitch(pitch)
        _playbackState.value = _playbackState.value.copy(pitch = pitch)
    }

    fun skipToNextChunk() {
        val next = _playbackState.value.currentChunkIndex + 1
        if (next < textChunks.size) {
            speakChunk(next)
        }
    }

    fun skipToPreviousChunk() {
        val prev = (_playbackState.value.currentChunkIndex - 1).coerceAtLeast(0)
        speakChunk(prev)
    }

    suspend fun exportAudioToMediaStore(
        bookTitle: String,
        fullText: String,
        language: TranslationLanguage,
        onProgress: (Float) -> Unit
    ): String = withContext(Dispatchers.IO) {
        _playbackState.value = _playbackState.value.copy(
            isSynthesizing = true,
            synthesisProgress = 0.1f,
            statusMessage = "Synthesizing Audio..."
        )

        val chunks = splitTextIntoTtsChunks(fullText)
        val tempFiles = mutableListOf<File>()

        try {
            tts?.setLanguage(language.locale)
            tts?.setSpeechRate(_playbackState.value.speechRate)
            tts?.setPitch(_playbackState.value.pitch)

            for ((i, chunk) in chunks.withIndex()) {
                val tempFile = File(context.cacheDir, "voxbook_temp_$i.wav")
                if (tempFile.exists()) tempFile.delete()

                val params = Bundle().apply {
                    putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "Synth_$i")
                }

                var synthSuccess = false
                val syncLock = Object()

                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}

                    override fun onDone(utteranceId: String?) {
                        synchronized(syncLock) {
                            synthSuccess = true
                            syncLock.notifyAll()
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        synchronized(syncLock) {
                            synthSuccess = false
                            syncLock.notifyAll()
                        }
                    }
                })

                val res = tts?.synthesizeToFile(chunk, params, tempFile, "Synth_$i")
                if (res == TextToSpeech.SUCCESS) {
                    synchronized(syncLock) {
                        syncLock.wait(10000) // 10 sec timeout per chunk
                    }
                }

                if (tempFile.exists() && tempFile.length() > 0) {
                    tempFiles.add(tempFile)
                }

                val progress = 0.1f + (0.7f * (i + 1) / chunks.size)
                onProgress(progress)
                _playbackState.value = _playbackState.value.copy(synthesisProgress = progress)
            }

            // Restore normal utterance listener
            setupUtteranceListener()

            if (tempFiles.isEmpty()) {
                throw IllegalStateException("TTS engine failed to synthesize audio files.")
            }

            // Combine temp WAV files into single output WAV
            val sanitizedTitle = bookTitle.replace(Regex("""[^a-zA-Z0-9_\-]"""), "_")
            val outputFileName = "VoxBook_${sanitizedTitle}_${language.code}.wav"

            val finalTempFile = File(context.cacheDir, outputFileName)
            combineWavFiles(tempFiles, finalTempFile)

            // Save to public Music / Downloads directory using MediaStore API
            val savedUriPath = saveFileToMediaStore(finalTempFile, outputFileName)

            _playbackState.value = _playbackState.value.copy(
                isSynthesizing = false,
                synthesisProgress = 1.0f,
                statusMessage = "Exported to Music directory!"
            )

            return@withContext savedUriPath

        } catch (e: Exception) {
            e.printStackTrace()
            setupUtteranceListener()
            _playbackState.value = _playbackState.value.copy(
                isSynthesizing = false,
                statusMessage = "Export failed: ${e.localizedMessage}"
            )
            throw e
        } finally {
            tempFiles.forEach { it.delete() }
        }
    }

    private fun saveFileToMediaStore(sourceFile: File, fileName: String): String {
        val resolver = context.contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
            put(MediaStore.Audio.Media.TITLE, fileName.removeSuffix(".wav"))
            put(MediaStore.Audio.Media.ARTIST, "VoxBook eBook Reader")
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/VoxBook")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
        }

        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val itemUri = resolver.insert(collection, contentValues)
            ?: throw IllegalStateException("Failed to create MediaStore entry.")

        resolver.openOutputStream(itemUri)?.use { outputStream ->
            FileInputStream(sourceFile).use { inputStream ->
                inputStream.copyTo(outputStream)
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            contentValues.clear()
            contentValues.put(MediaStore.Audio.Media.IS_PENDING, 0)
            resolver.update(itemUri, contentValues, null, null)
        }

        return "Music/VoxBook/$fileName"
    }

    private fun combineWavFiles(inputs: List<File>, output: File) {
        if (inputs.isEmpty()) return
        if (inputs.size == 1) {
            inputs[0].copyTo(output, overwrite = true)
            return
        }

        // Concatenate audio payloads while keeping WAV header valid
        FileOutputStream(output).use { fos ->
            inputs.forEachIndexed { index, file ->
                FileInputStream(file).use { fis ->
                    if (index > 0) {
                        // Skip 44-byte WAV header for subsequent files
                        fis.skip(44)
                    }
                    fis.copyTo(fos)
                }
            }
        }
    }

    private fun splitTextIntoTtsChunks(text: String, maxChunkSize: Int = 2000): List<String> {
        if (text.length <= maxChunkSize) return listOf(text)

        val sentences = text.split(Regex("""(?<=[.!?\n])\s+"""))
        val chunks = mutableListOf<String>()
        var current = StringBuilder()

        for (sentence in sentences) {
            if (current.length + sentence.length + 1 > maxChunkSize) {
                if (current.isNotEmpty()) {
                    chunks.add(current.toString().trim())
                    current = StringBuilder()
                }
                if (sentence.length > maxChunkSize) {
                    // Force split long sentence
                    var i = 0
                    while (i < sentence.length) {
                        val end = (i + maxChunkSize).coerceAtMost(sentence.length)
                        chunks.add(sentence.substring(i, end).trim())
                        i = end
                    }
                } else {
                    current.append(sentence).append(" ")
                }
            } else {
                current.append(sentence).append(" ")
            }
        }

        if (current.isNotEmpty()) {
            chunks.add(current.toString().trim())
        }

        return if (chunks.isEmpty()) listOf(text) else chunks
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
