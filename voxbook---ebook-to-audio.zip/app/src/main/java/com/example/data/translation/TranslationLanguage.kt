package com.example.data.translation

import java.util.Locale

data class TranslationLanguage(
    val name: String,
    val nativeName: String,
    val code: String,
    val locale: Locale,
    val flagEmoji: String
) {
    companion object {
        val SUPPORTED_LANGUAGES = listOf(
            TranslationLanguage("Hindi", "हिंदी", "hi", Locale("hi", "IN"), "🇮🇳"),
            TranslationLanguage("Marathi", "मराठी", "mr", Locale("mr", "IN"), "🇮🇳"),
            TranslationLanguage("Tamil", "தமிழ்", "ta", Locale("ta", "IN"), "🇮🇳"),
            TranslationLanguage("Telugu", "తెలుగు", "te", Locale("te", "IN"), "🇮🇳"),
            TranslationLanguage("Bengali", "বাংলা", "bn", Locale("bn", "IN"), "🇮🇳"),
            TranslationLanguage("Gujarati", "ગુજરાતી", "gu", Locale("gu", "IN"), "🇮🇳"),
            TranslationLanguage("Kannada", "ಕನ್ನಡ", "kn", Locale("kn", "IN"), "🇮🇳"),
            TranslationLanguage("Malayalam", "മലയാളം", "ml", Locale("ml", "IN"), "🇮🇳"),
            TranslationLanguage("Punjabi", "ਪੰਜਾਬੀ", "pa", Locale("pa", "IN"), "🇮🇳"),
            TranslationLanguage("Urdu", "اردو", "ur", Locale("ur", "IN"), "🇮🇳"),
            TranslationLanguage("English", "English", "en", Locale.US, "🇺🇸"),
            TranslationLanguage("Spanish", "Español", "es", Locale("es", "ES"), "🇪🇸"),
            TranslationLanguage("French", "Français", "fr", Locale.FRANCE, "🇫🇷"),
            TranslationLanguage("German", "Deutsch", "de", Locale.GERMANY, "🇩🇪")
        )

        fun findByCode(code: String): TranslationLanguage {
            return SUPPORTED_LANGUAGES.find { it.code.equals(code, ignoreCase = true) }
                ?: SUPPORTED_LANGUAGES.first()
        }

        fun findByName(name: String): TranslationLanguage {
            return SUPPORTED_LANGUAGES.find { it.name.equals(name, ignoreCase = true) }
                ?: SUPPORTED_LANGUAGES.first()
        }
    }
}
