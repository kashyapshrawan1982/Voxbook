package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "books")
data class BookItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val fileType: String, // "TXT", "PDF", "EPUB"
    val originalText: String,
    val translatedText: String = "",
    val sourceLanguage: String = "English",
    val targetLanguage: String = "English",
    val targetLanguageCode: String = "en",
    val audioFilePath: String? = null,
    val durationSeconds: Int = 0,
    val wordCount: Int = 0,
    val charCount: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)
