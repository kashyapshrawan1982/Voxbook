package com.example.data.translation

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

object TranslationService {

    suspend fun translateText(
        text: String,
        sourceLangCode: String = "auto",
        targetLang: TranslationLanguage,
        onProgress: (Float) -> Unit = {}
    ): String = withContext(Dispatchers.IO) {
        if (text.isBlank()) return@withContext ""
        if (sourceLangCode.lowercase() == targetLang.code.lowercase()) return@withContext text

        val apiKey = BuildConfig.GEMINI_API_KEY
        if (!apiKey.isNullOrEmpty() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                return@withContext translateWithGemini(text, targetLang, apiKey, onProgress)
            } catch (e: Exception) {
                e.printStackTrace()
                // Fallback to REST endpoint
            }
        }

        return@withContext translateWithRestApi(text, sourceLangCode, targetLang.code, onProgress)
    }

    private suspend fun translateWithGemini(
        text: String,
        targetLang: TranslationLanguage,
        apiKey: String,
        onProgress: (Float) -> Unit
    ): String {
        val urlString = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
        val url = URL(urlString)
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true

        val prompt = "Translate the following text accurately into ${targetLang.name} (${targetLang.nativeName}). Maintain line breaks and paragraph structure. Return ONLY the translation without preamble or additional commentary:\n\n$text"

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            })
        }

        onProgress(0.3f)
        conn.outputStream.use { os ->
            os.write(jsonBody.toString().toByteArray(StandardCharsets.UTF_8))
        }

        onProgress(0.7f)
        val responseCode = conn.responseCode
        if (responseCode == HttpURLConnection.HTTP_OK) {
            val responseText = conn.inputStream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }
            val jsonResponse = JSONObject(responseText)
            val candidates = jsonResponse.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val candidate = candidates.getJSONObject(0)
                val content = candidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val translated = parts.getJSONObject(0).optString("text", "")
                    onProgress(1.0f)
                    return translated.trim()
                }
            }
        }
        
        throw IllegalStateException("Gemini translation API returned response code $responseCode")
    }

    private suspend fun translateWithRestApi(
        text: String,
        sourceLangCode: String,
        targetLangCode: String,
        onProgress: (Float) -> Unit
    ): String {
        // Split text into ~500 character chunks for free REST endpoint limits
        val chunks = splitTextIntoChunks(text, maxChars = 500)
        val translatedChunks = mutableListOf<String>()

        val total = chunks.size
        for ((index, chunk) in chunks.withIndex()) {
            if (chunk.isBlank()) {
                translatedChunks.add("")
                continue
            }
            try {
                val translated = translateSingleChunk(chunk, sourceLangCode, targetLangCode)
                translatedChunks.add(translated)
            } catch (e: Exception) {
                e.printStackTrace()
                translatedChunks.add(chunk) // Fallback to original chunk if network error
            }
            val progress = (index + 1).toFloat() / total
            onProgress(progress)
        }

        return translatedChunks.joinToString("\n\n")
    }

    private fun translateSingleChunk(
        chunk: String,
        sourceLangCode: String,
        targetLangCode: String
    ): String {
        // MyMemory / Free Translate REST API endpoint
        val src = if (sourceLangCode == "auto") "en" else sourceLangCode
        val langPair = "$src|$targetLangCode"
        val encodedText = URLEncoder.encode(chunk, StandardCharsets.UTF_8.name())
        val urlString = "https://api.mymemory.translated.net/get?q=$encodedText&langpair=$langPair"

        val url = URL(urlString)
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 8000
        conn.readTimeout = 8000

        if (conn.responseCode == HttpURLConnection.HTTP_OK) {
            val responseText = conn.inputStream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }
            val json = JSONObject(responseText)
            val responseData = json.optJSONObject("responseData")
            val translatedText = responseData?.optString("translatedText")
            if (!translatedText.isNullOrBlank() && !translatedText.contains("QUERY LENGTH LIMIT")) {
                return translatedText
            }
        }
        
        return chunk
    }

    private fun splitTextIntoChunks(text: String, maxChars: Int): List<String> {
        val paragraphs = text.split("\n\n")
        val chunks = mutableListOf<String>()
        var currentChunk = StringBuilder()

        for (para in paragraphs) {
            if (currentChunk.length + para.length + 2 > maxChars) {
                if (currentChunk.isNotEmpty()) {
                    chunks.add(currentChunk.toString().trim())
                    currentChunk = StringBuilder()
                }
                if (para.length > maxChars) {
                    // Split long paragraph by sentences
                    val sentences = para.split(Regex("""(?<=[.!?])\s+"""))
                    for (sentence in sentences) {
                        if (currentChunk.length + sentence.length + 1 > maxChars) {
                            if (currentChunk.isNotEmpty()) {
                                chunks.add(currentChunk.toString().trim())
                                currentChunk = StringBuilder()
                            }
                            currentChunk.append(sentence).append(" ")
                        } else {
                            currentChunk.append(sentence).append(" ")
                        }
                    }
                } else {
                    currentChunk.append(para).append("\n\n")
                }
            } else {
                currentChunk.append(para).append("\n\n")
            }
        }

        if (currentChunk.isNotEmpty()) {
            chunks.add(currentChunk.toString().trim())
        }

        return if (chunks.isEmpty()) listOf(text) else chunks
    }
}
