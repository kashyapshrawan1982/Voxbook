package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val IndigoPrimary = Color(0xFF1E293B)
val IndigoSecondary = Color(0xFF334155)
val AmberAccent = Color(0xFFF59E0B)
val AmberAccentLight = Color(0xFFFDE68A)

val IndigoDarkPrimary = Color(0xFF38BDF8)
val IndigoDarkBackground = Color(0xFF0F172A)
val IndigoDarkSurface = Color(0xFF1E293B)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)

val PrimaryBlue = Color(0xFF2563EB)
val PrimaryBlueContainer = Color(0xFFDBEAFE)
val SecondaryTeal = Color(0xFF0D9488)
