package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PlayerExportScreen
import com.example.ui.screens.PreviewTranslateScreen
import com.example.viewmodel.BookViewModel

object Routes {
    const val HOME = "home"
    const val PREVIEW = "preview/{bookId}"
    const val PLAYER = "player/{bookId}"

    fun previewRoute(bookId: Long) = "preview/$bookId"
    fun playerRoute(bookId: Long) = "player/$bookId"
}

@Composable
fun VoxBookNavGraph(
    navController: NavHostController,
    viewModel: BookViewModel
) {
    NavHost(
        navController = navController,
        startDestination = Routes.HOME
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                viewModel = viewModel,
                onNavigateToPreview = { bookId ->
                    navController.navigate(Routes.previewRoute(bookId))
                },
                onNavigateToPlayer = { bookId ->
                    navController.navigate(Routes.playerRoute(bookId))
                }
            )
        }

        composable(
            route = Routes.PREVIEW,
            arguments = listOf(navArgument("bookId") { type = NavType.LongType })
        ) { backStackEntry ->
            val bookId = backStackEntry.arguments?.getLong("bookId") ?: 0L
            PreviewTranslateScreen(
                viewModel = viewModel,
                bookId = bookId,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToPlayer = { id ->
                    navController.navigate(Routes.playerRoute(id))
                }
            )
        }

        composable(
            route = Routes.PLAYER,
            arguments = listOf(navArgument("bookId") { type = NavType.LongType })
        ) { backStackEntry ->
            val bookId = backStackEntry.arguments?.getLong("bookId") ?: 0L
            PlayerExportScreen(
                viewModel = viewModel,
                bookId = bookId,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
