package com.example.data.parser

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.util.zip.ZipInputStream

object FileParser {

    data class ParsedResult(
        val fileName: String,
        val fileType: String,
        val text: String,
        val fileSizeFormatted: String
    )

    fun parseFile(context: Context, uri: Uri): ParsedResult {
        val fileName = getFileName(context, uri) ?: "Document"
        val fileSize = getFileSize(context, uri)
        val fileType = when {
            fileName.endsWith(".pdf", ignoreCase = true) -> "PDF"
            fileName.endsWith(".epub", ignoreCase = true) -> "EPUB"
            else -> "TXT"
        }

        val text = context.contentResolver.openInputStream(uri)?.use { inputStream ->
            when (fileType) {
                "TXT" -> parseTxt(inputStream)
                "PDF" -> parsePdf(context, inputStream)
                "EPUB" -> parseEpub(inputStream)
                else -> parseTxt(inputStream)
            }
        } ?: throw IllegalStateException("Could not open input stream for file")

        val cleanedText = cleanExtractedText(text)
        return ParsedResult(
            fileName = fileName,
            fileType = fileType,
            text = cleanedText,
            fileSizeFormatted = formatFileSize(fileSize)
        )
    }

    private fun parseTxt(inputStream: InputStream): String {
        return BufferedReader(InputStreamReader(inputStream, StandardCharsets.UTF_8)).use { reader ->
            reader.readText()
        }
    }

    private fun parseEpub(inputStream: InputStream): String {
        val stringBuilder = StringBuilder()
        ZipInputStream(inputStream).use { zipStream ->
            var entry = zipStream.nextEntry
            while (entry != null) {
                val name = entry.name.lowercase()
                if ((name.endsWith(".xhtml") || name.endsWith(".html") || name.endsWith(".htm"))
                    && !name.contains("toc") && !name.contains("cover")
                ) {
                    val content = BufferedReader(InputStreamReader(zipStream, StandardCharsets.UTF_8)).use {
                        val sb = StringBuilder()
                        var line: String? = zipStream.bufferedReader().readLine()
                        while (line != null) {
                            sb.append(line).append("\n")
                            line = zipStream.bufferedReader().readLine()
                        }
                        sb.toString()
                    }
                    stringBuilder.append(stripHtmlTags(content)).append("\n\n")
                }
                zipStream.closeEntry()
                entry = zipStream.nextEntry
            }
        }
        val result = stringBuilder.toString()
        return if (result.isBlank()) "No readable text content found in EPUB document." else result
    }

    private fun parsePdf(context: Context, inputStream: InputStream): String {
        return try {
            PDFBoxResourceLoader.init(context)
            PDDocument.load(inputStream).use { document ->
                val stripper = PDFTextStripper()
                stripper.sortByPosition = true
                val extractedText = stripper.getText(document)
                if (extractedText.isNullOrBlank()) {
                    "No readable text extracted from PDF. If this document is a scanned image, OCR scanning is required."
                } else {
                    extractedText.trim()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            "Error parsing PDF document: ${e.localizedMessage ?: "Invalid or encrypted PDF file"}"
        }
    }

    private fun stripHtmlTags(html: String): String {
        val noTags = html.replace(Regex("""<[^>]*>"""), " ")
        return noTags
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    private fun cleanExtractedText(raw: String): String {
        return raw.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .joinToString("\n\n")
    }

    fun getFileName(context: Context, uri: Uri): String? {
        var name: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1 && cursor.moveToFirst()) {
                    name = cursor.getString(nameIndex)
                }
            }
        }
        if (name == null) {
            name = uri.path
            val cut = name?.lastIndexOf('/')
            if (cut != null && cut != -1) {
                name = name.substring(cut + 1)
            }
        }
        return name
    }

    private fun getFileSize(context: Context, uri: Uri): Long {
        var size: Long = 0
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (sizeIndex != -1 && cursor.moveToFirst()) {
                    size = cursor.getLong(sizeIndex)
                }
            }
        }
        return size
    }

    private fun formatFileSize(size: Long): String {
        if (size <= 0) return "Unknown size"
        val kb = size / 1024.0
        val mb = kb / 1024.0
        return when {
            mb >= 1.0 -> String.format("%.1f MB", mb)
            else -> String.format("%.0f KB", kb)
        }
    }
}
